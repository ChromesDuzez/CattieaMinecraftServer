# No trial chambers
A simple data pack that enables the Update 1.21 experimental features, but disables the trial chambers and breeze.

Made for Minecraft: Java Edition 1.20.4
